package com.healthcare.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthcareportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthcareportalApplication.class, args);
	}

}
