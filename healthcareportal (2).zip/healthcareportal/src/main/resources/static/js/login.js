const role = document.getElementById("role");
const label = document.getElementById("userLabel");
const input = document.getElementById("email");

// Change Email Label Based on Role
role.addEventListener("change", function () {

    switch (role.value) {

        case "admin":
            label.innerHTML = "Admin Email";
            input.placeholder = "Enter Admin Email";
            break;

        case "doctor":
            label.innerHTML = "Doctor Email";
            input.placeholder = "Enter Doctor Email";
            break;

        default:
            label.innerHTML = "Patient Email";
            input.placeholder = "Enter Patient Email";

    }

});

// Login Form
document.getElementById("loginForm").addEventListener("submit", async function (e) {

    e.preventDefault();

    let API_URL = "";

    switch (role.value) {

        case "patient":
            API_URL = "http://localhost:8080/api/patients/login";
            break;

        case "doctor":
            API_URL = "http://localhost:8080/api/doctors/login";
            break;

        case "admin":
            API_URL = "http://localhost:8080/api/admin/login";
            break;

        default:
            alert("Please select a role.");
            return;

    }

    const user = {
        email: input.value.trim(),
        password: document.getElementById("password").value.trim()
    };

    try {

        const response = await fetch(API_URL, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify(user)

        });

        if (!response.ok) {

            const message = await response.text();

            alert("Login Failed!\n" + message);

            return;

        }

        const data = await response.json();

        // Clear Previous Sessions
        localStorage.removeItem("patient");
        localStorage.removeItem("doctor");
        localStorage.removeItem("admin");

        // Store Logged-in User
        if (role.value === "patient") {

            localStorage.setItem("patient", JSON.stringify(data));

            alert("Welcome " + data.name);

            window.location.href = "patient-dashboard.html";

        }
        else if (role.value === "doctor") {

            localStorage.setItem("doctor", JSON.stringify(data));

            alert("Welcome Dr. " + data.name);

            window.location.href = "doctor-dashboard.html";

        }
        else {

            localStorage.setItem("admin", JSON.stringify(data));

            alert("Welcome Admin");

            window.location.href = "admin-dashboard.html";

        }

    }
    catch (error) {

        console.error(error);

        alert("Unable to connect to the server.");

    }

});