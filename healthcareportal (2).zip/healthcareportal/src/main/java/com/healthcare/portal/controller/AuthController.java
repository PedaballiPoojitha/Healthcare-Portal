package com.healthcare.portal.controller;

public class AuthController {
}
