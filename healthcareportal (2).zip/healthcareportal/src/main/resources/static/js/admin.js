const admin = JSON.parse(localStorage.getItem("admin"));

if (!admin) {
    window.location.href = "login.html";
}

document.getElementById("welcome").innerHTML =
    "Welcome, " + admin.name;

loadDashboard();

async function loadDashboard() {

    try {

        // Fetch all data
        const patients = await fetch("http://localhost:8080/api/patients")
            .then(res => res.json());

        const doctors = await fetch("http://localhost:8080/api/doctors")
            .then(res => res.json());

        const appointments = await fetch("http://localhost:8080/api/appointments")
            .then(res => res.json());

        const prescriptions = await fetch("http://localhost:8080/api/prescriptions")
            .then(res => res.json());

        // Update dashboard cards
        document.getElementById("patientCount").innerHTML = patients.length;
        document.getElementById("doctorCount").innerHTML = doctors.length;
        document.getElementById("appointmentCount").innerHTML = appointments.length;
        document.getElementById("prescriptionCount").innerHTML = prescriptions.length;

        // Appointment Status Counts
        let booked = 0;
        let approved = 0;
        let completed = 0;

        appointments.forEach(app => {

            if (app.status === "Booked") {

                booked++;

            } else if (app.status === "Approved") {

                approved++;

            } else if (app.status === "Completed") {

                completed++;

            }

        });

        // Remove previous chart if it exists
        const oldChart = Chart.getChart("appointmentChart");

        if (oldChart) {
            oldChart.destroy();
        }

        // Create Chart
        new Chart(document.getElementById("appointmentChart"), {

            type: "bar",

            data: {

                labels: [
                    "Booked",
                    "Approved",
                    "Completed"
                ],

                datasets: [

                    {

                        label: "Appointments",

                        data: [
                            booked,
                            approved,
                            completed
                        ],

                        backgroundColor: [
                            "#ffc107",
                            "#0d6efd",
                            "#198754"
                        ],

                        borderWidth: 1

                    }

                ]

            },

            options: {

                responsive: true,
                maintainAspectRatio: false,

                plugins: {

                    legend: {

                        display: false

                    }

                },

                scales: {

                    y: {

                        beginAtZero: true,

                        ticks: {

                            precision: 0

                        }

                    }

                }

            }

        });

    }

    catch (error) {

        console.error(error);

        alert("Unable to load dashboard.");

    }

}

function logout() {

    localStorage.removeItem("admin");

    window.location.href = "login.html";

}