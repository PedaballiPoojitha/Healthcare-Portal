package com.healthcare.portal.config;

public class DatabaseConfig {
}
