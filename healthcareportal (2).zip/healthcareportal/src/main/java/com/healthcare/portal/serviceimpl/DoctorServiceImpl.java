package com.healthcare.portal.serviceimpl;

import com.healthcare.portal.entity.Doctor;
import com.healthcare.portal.exception.ResourceNotFoundException;
import com.healthcare.portal.repository.DoctorRepository;
import com.healthcare.portal.service.DoctorService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorServiceImpl implements DoctorService {

    private final DoctorRepository repository;

    public DoctorServiceImpl(DoctorRepository repository) {
        this.repository = repository;
    }

    @Override
    public Doctor saveDoctor(Doctor doctor) {
        return repository.save(doctor);
    }

    @Override
    public List<Doctor> getAllDoctors() {
        return repository.findAll();
    }

    @Override
    public Doctor getDoctorById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));
    }

    @Override
    public Doctor updateDoctor(Long id, Doctor doctor) {

        Doctor existing = getDoctorById(id);

        existing.setName(doctor.getName());
        existing.setEmail(doctor.getEmail());
        existing.setPassword(doctor.getPassword());
        existing.setPhone(doctor.getPhone());
        existing.setSpecialization(doctor.getSpecialization());
        existing.setQualification(doctor.getQualification());
        existing.setExperience(doctor.getExperience());
        existing.setConsultationFee(doctor.getConsultationFee());
        existing.setAvailability(doctor.getAvailability());

        return repository.save(existing);
    }

    @Override
    public void deleteDoctor(Long id) {
        repository.deleteById(id);
    }

    @Override
    public List<Doctor> getDoctorsBySpecialization(String specialization) {
        return repository.findBySpecialization(specialization);
    }
    @Override
    public Doctor login(String email, String password) {

        return repository.findByEmailAndPassword(email, password)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Invalid Email or Password"));
    }
}