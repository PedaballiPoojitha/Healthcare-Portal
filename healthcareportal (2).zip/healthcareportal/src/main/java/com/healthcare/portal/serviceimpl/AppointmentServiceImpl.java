package com.healthcare.portal.serviceimpl;

import com.healthcare.portal.entity.Appointment;
import com.healthcare.portal.exception.ResourceNotFoundException;
import com.healthcare.portal.repository.AppointmentRepository;
import com.healthcare.portal.service.AppointmentService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentServiceImpl implements AppointmentService {

    private final AppointmentRepository repository;

    public AppointmentServiceImpl(AppointmentRepository repository) {
        this.repository = repository;
    }

    @Override
    public Appointment bookAppointment(Appointment appointment) {
        return repository.save(appointment);
    }

    @Override
    public List<Appointment> getAllAppointments() {
        return repository.findAll();
    }

    @Override
    public Appointment getAppointmentById(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Appointment not found"));
    }

    @Override
    public Appointment updateAppointment(Long id, Appointment appointment) {

        Appointment existing = getAppointmentById(id);

        existing.setAppointmentDate(appointment.getAppointmentDate());
        existing.setAppointmentTime(appointment.getAppointmentTime());
        existing.setReason(appointment.getReason());
        existing.setStatus(appointment.getStatus());

        return repository.save(existing);
    }

    @Override
    public void deleteAppointment(Long id) {
        repository.deleteById(id);
    }

    @Override
    public List<Appointment> getAppointmentsByPatient(Long patientId) {
        return repository.findByPatientId(patientId);
    }

    @Override
    public List<Appointment> getAppointmentsByDoctor(Long doctorId) {
        return repository.findByDoctorId(doctorId);
    }
}