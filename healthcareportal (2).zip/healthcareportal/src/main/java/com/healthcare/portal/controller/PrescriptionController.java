package com.healthcare.portal.controller;

import com.healthcare.portal.entity.Prescription;
import com.healthcare.portal.service.PrescriptionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/prescriptions")
@CrossOrigin(origins = "*")
public class PrescriptionController {

    private final PrescriptionService service;

    public PrescriptionController(PrescriptionService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<?> addPrescription(@RequestBody Prescription prescription) {

        try {

            Prescription saved = service.savePrescription(prescription);

            return ResponseEntity.ok(saved);

        } catch (RuntimeException e) {

            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("message", e.getMessage()));
        }
    }

    @GetMapping
    public List<Prescription> getAllPrescriptions() {
        return service.getAllPrescriptions();
    }

    @GetMapping("/{id}")
    public Prescription getPrescription(@PathVariable Long id) {
        return service.getPrescriptionById(id);
    }

    @GetMapping("/patient/{patientId}")
    public List<Prescription> getPatientPrescriptions(@PathVariable Long patientId) {
        return service.getPrescriptionsByPatient(patientId);
    }

    @PutMapping("/{id}")
    public Prescription updatePrescription(@PathVariable Long id,
                                           @RequestBody Prescription prescription) {
        return service.updatePrescription(id, prescription);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePrescription(@PathVariable Long id) {

        service.deletePrescription(id);

        return ResponseEntity.ok("Prescription deleted successfully");
    }
}