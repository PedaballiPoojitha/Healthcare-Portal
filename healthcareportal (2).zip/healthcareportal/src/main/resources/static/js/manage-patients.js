const API_URL = "http://localhost:8080/api/patients";

window.onload = () => {
    loadPatients();
};

// =============================
// Load Patients
// =============================
async function loadPatients() {

    const table = document.getElementById("patientTable");

    table.innerHTML = `
        <tr>
            <td colspan="8" class="text-center p-4">
                <div class="spinner-border text-primary"></div>
                <br><br>
                Loading Patients...
            </td>
        </tr>
    `;

    try {

        const response = await fetch(API_URL);

        if (!response.ok) {
            throw new Error("Unable to fetch patients");
        }

        const patients = await response.json();

        document.getElementById("totalPatients").innerHTML = patients.length;

        let rows = "";

        if (patients.length === 0) {

            rows = `
                <tr>
                    <td colspan="8" class="text-center text-danger">
                        No Patients Found
                    </td>
                </tr>
            `;

        } else {

            patients.forEach((patient, index) => {

                rows += `
                <tr>

                    <td>${index + 1}</td>

                    <td>${patient.name}</td>

                    <td>${patient.email}</td>

                    <td>${patient.phone}</td>

                    <td>${patient.gender}</td>

                    <td>${patient.age}</td>

                    <td>${patient.address}</td>

                    <td>

                        <button
                            class="btn btn-info btn-sm me-1"
                            onclick="viewPatient(${patient.id})">

                            <i class="fa-solid fa-eye"></i>

                        </button>

                        <button
                            class="btn btn-danger btn-sm"
                            onclick="deletePatient(${patient.id})">

                            <i class="fa-solid fa-trash"></i>

                        </button>

                    </td>

                </tr>
                `;

            });

        }

        table.innerHTML = rows;

    }

    catch (error) {

        console.error(error);

        table.innerHTML = `
            <tr>
                <td colspan="8" class="text-center text-danger">
                    Unable to Load Patients
                </td>
            </tr>
        `;

    }

}

// =============================
// Delete Patient
// =============================
async function deletePatient(id) {

    if (!confirm("Are you sure you want to delete this patient?")) {
        return;
    }

    try {

        const response = await fetch(`${API_URL}/${id}`, {
            method: "DELETE"
        });

        if (response.ok) {

            alert("Patient Deleted Successfully");

            loadPatients();

        } else {

            alert("Unable to Delete Patient");

        }

    } catch (error) {

        console.error(error);

        alert("Server Error");

    }

}

// =============================
// View Patient
// =============================
async function viewPatient(id) {

    try {

        const response = await fetch(`${API_URL}/${id}`);

        if (!response.ok) {
            throw new Error();
        }

        const patient = await response.json();

        alert(
            `Patient Details

ID : ${patient.id}

Name : ${patient.name}

Email : ${patient.email}

Phone : ${patient.phone}

Gender : ${patient.gender}

Age : ${patient.age}

Address : ${patient.address}`
        );

    }

    catch {

        alert("Unable to Fetch Patient Details");

    }

}

// =============================
// Search Patient
// =============================
function searchPatient() {

    let input = document.getElementById("search").value.toUpperCase();

    let table = document.getElementById("patientTable");

    let rows = table.getElementsByTagName("tr");

    for (let i = 0; i < rows.length; i++) {

        let name = rows[i].getElementsByTagName("td")[1];

        if (name) {

            let value = name.textContent || name.innerText;

            rows[i].style.display =
                value.toUpperCase().indexOf(input) > -1
                    ? ""
                    : "none";

        }

    }

}

// =============================
// Refresh Patients
// =============================
function refreshPatients() {

    loadPatients();

}

// =============================
// Export Patients CSV
// =============================
function exportPatients() {

    let table = document.getElementById("patientTable");

    let csv = [];

    csv.push("S.No,Name,Email,Phone,Gender,Age,Address");

    let rows = table.querySelectorAll("tr");

    rows.forEach(row => {

        let cols = row.querySelectorAll("td");

        if (cols.length > 0) {

            let data = [];

            for (let i = 0; i < 7; i++) {

                let text = cols[i].innerText
                    .replace(/\n/g, " ")
                    .replace(/,/g, " ");

                data.push(text);

            }

            csv.push(data.join(","));

        }

    });

    let blob = new Blob([csv.join("\n")], {
        type: "text/csv"
    });

    let link = document.createElement("a");

    link.href = URL.createObjectURL(blob);

    link.download = "Patients.csv";

    document.body.appendChild(link);

    link.click();

    document.body.removeChild(link);

}