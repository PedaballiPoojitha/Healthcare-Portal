package com.healthcare.portal.controller;

import com.healthcare.portal.entity.Admin;
import com.healthcare.portal.service.AdminService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins="*")
public class AdminController {

    private final AdminService service;

    public AdminController(AdminService service){
        this.service=service;
    }

    @PostMapping
    public Admin saveAdmin(@RequestBody Admin admin){
        return service.saveAdmin(admin);
    }

    @PostMapping("/login")
    public Admin login(@RequestBody Admin admin){
        return service.login(admin.getEmail(),admin.getPassword());
    }

    @GetMapping
    public List<Admin> getAllAdmins(){
        return service.getAllAdmins();
    }

}