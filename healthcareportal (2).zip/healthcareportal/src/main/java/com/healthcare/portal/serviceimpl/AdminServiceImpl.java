package com.healthcare.portal.serviceimpl;

import com.healthcare.portal.entity.Admin;
import com.healthcare.portal.exception.ResourceNotFoundException;
import com.healthcare.portal.repository.AdminRepository;
import com.healthcare.portal.service.AdminService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {

    private final AdminRepository repository;

    public AdminServiceImpl(AdminRepository repository){
        this.repository=repository;
    }

    @Override
    public Admin saveAdmin(Admin admin){
        return repository.save(admin);
    }

    @Override
    public List<Admin> getAllAdmins(){
        return repository.findAll();
    }

    @Override
    public Admin login(String email,String password){

        Admin admin=repository.findByEmail(email)
                .orElseThrow(()->new ResourceNotFoundException("Admin Not Found"));

        if(!admin.getPassword().equals(password)){
            throw new RuntimeException("Invalid Password");
        }

        return admin;
    }
}