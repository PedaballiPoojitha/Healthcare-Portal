package com.healthcare.portal.serviceimpl;

import com.healthcare.portal.entity.Prescription;
import com.healthcare.portal.exception.ResourceNotFoundException;
import com.healthcare.portal.repository.PrescriptionRepository;
import com.healthcare.portal.service.PrescriptionService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PrescriptionServiceImpl implements PrescriptionService {

    private final PrescriptionRepository repository;

    public PrescriptionServiceImpl(PrescriptionRepository repository) {
        this.repository = repository;
    }

    @Override
    public Prescription savePrescription(Prescription prescription) {

        Long appointmentId = prescription.getAppointment().getId();

        Optional<Prescription> existing =
                repository.findByAppointmentId(appointmentId);

        if (existing.isPresent()) {
            throw new RuntimeException("Prescription already exists for this appointment.");
        }

        return repository.save(prescription);
    }

    @Override
    public List<Prescription> getAllPrescriptions() {
        return repository.findAll();
    }

    @Override
    public Prescription getPrescriptionById(Long id) {
        return repository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Prescription not found"));
    }

    @Override
    public Prescription updatePrescription(Long id, Prescription prescription) {

        Prescription existing = getPrescriptionById(id);

        existing.setAppointment(prescription.getAppointment());
        existing.setDiagnosis(prescription.getDiagnosis());
        existing.setMedicines(prescription.getMedicines());
        existing.setDosage(prescription.getDosage());
        existing.setNotes(prescription.getNotes());

        return repository.save(existing);
    }

    @Override
    public List<Prescription> getPrescriptionsByPatient(Long patientId) {
        return repository.findByAppointmentPatientId(patientId);
    }

    @Override
    public void deletePrescription(Long id) {
        repository.deleteById(id);
    }
}