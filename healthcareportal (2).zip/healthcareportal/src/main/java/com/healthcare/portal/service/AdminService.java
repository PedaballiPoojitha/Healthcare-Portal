package com.healthcare.portal.service;

import com.healthcare.portal.entity.Admin;

import java.util.List;

public interface AdminService {

    Admin saveAdmin(Admin admin);

    List<Admin> getAllAdmins();

    Admin login(String email,String password);

}