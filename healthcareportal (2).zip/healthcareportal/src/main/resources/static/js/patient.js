const patient = JSON.parse(localStorage.getItem("patient"));

if (!patient) {

    window.location.href = "login.html";

}

document.getElementById("welcome").innerHTML =
    "Welcome, " + patient.name;

document.getElementById("name").innerHTML = patient.name;
document.getElementById("email").innerHTML = patient.email;
document.getElementById("phone").innerHTML = patient.phone;
document.getElementById("gender").innerHTML = patient.gender;
document.getElementById("age").innerHTML = patient.age;
document.getElementById("address").innerHTML = patient.address;

function logout() {

    localStorage.removeItem("patient");

    window.location.href = "login.html";

}

function showProfile() {

    document.getElementById("profileCard")
        .scrollIntoView({
            behavior: "smooth"
        });

}