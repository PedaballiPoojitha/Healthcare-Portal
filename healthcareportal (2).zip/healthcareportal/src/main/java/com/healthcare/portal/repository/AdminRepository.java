package com.healthcare.portal.repository;

import com.healthcare.portal.entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AdminRepository extends JpaRepository<Admin,Long>{

    Optional<Admin> findByEmail(String email);

}