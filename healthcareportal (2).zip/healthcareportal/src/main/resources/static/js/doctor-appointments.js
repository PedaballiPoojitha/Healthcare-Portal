const doctor = JSON.parse(localStorage.getItem("doctor"));

if (!doctor) {
    window.location.href = "login.html";
}

loadAppointments();

async function loadAppointments() {

    try {

        const response = await fetch(
            `http://localhost:8080/api/appointments/doctor/${doctor.id}`
        );

        const appointments = await response.json();

        let rows = "";

        appointments.forEach(app => {

            let action = "";

            if (app.status === "Booked") {

                action = `
                    <button class="btn btn-success btn-sm"
                        onclick="updateStatus(${app.id}, 'Approved')">
                        Approve
                    </button>
                `;

            } else if (app.status === "Approved") {

                action = `
                    <button class="btn btn-warning btn-sm"
                        onclick="updateStatus(${app.id}, 'Completed')">
                        Complete
                    </button>
                `;

            } else if (app.status === "Completed") {

                action = `
                    <a href="prescription.html?id=${app.id}"
                       class="btn btn-primary btn-sm">
                        Prescription
                    </a>
                `;

            } else {

                action = "-";

            }

            rows += `
                <tr>

                    <td>${app.id}</td>

                    <td>${app.patient.name}</td>

                    <td>${app.appointmentDate}</td>

                    <td>${app.appointmentTime}</td>

                    <td>${app.reason}</td>

                    <td>${app.status}</td>

                    <td>${action}</td>

                </tr>
            `;

        });

        document.getElementById("appointmentTable").innerHTML = rows;

    } catch (error) {

        console.error(error);

        alert("Unable to load appointments.");

    }

}

async function updateStatus(id, status) {

    try {

        // Get appointment details
        const response = await fetch(
            `http://localhost:8080/api/appointments/${id}`
        );

        const appointment = await response.json();

        // Update status
        appointment.status = status;

        // Save updated appointment
        const updateResponse = await fetch(
            `http://localhost:8080/api/appointments/${id}`,
            {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(appointment)
            }
        );

        if (updateResponse.ok) {

            alert("Appointment Updated Successfully");

            loadAppointments();

        } else {

            alert("Failed to update appointment.");

        }

    } catch (error) {

        console.error(error);

        alert("Server Error");

    }

}