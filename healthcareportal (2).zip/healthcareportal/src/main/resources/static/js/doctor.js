const doctor = JSON.parse(localStorage.getItem("doctor"));

if (doctor) {

    // Welcome Message
    document.getElementById("welcome").innerHTML =
        "Welcome " + doctor.name;

    // Doctor Details
    document.getElementById("name").innerHTML = doctor.name;
    document.getElementById("email").innerHTML = doctor.email;
    document.getElementById("phone").innerHTML = doctor.phone;
    document.getElementById("specialization").innerHTML = doctor.specialization;
    document.getElementById("qualification").innerHTML = doctor.qualification;
    document.getElementById("experience").innerHTML = doctor.experience;
    document.getElementById("fee").innerHTML = doctor.consultationFee;
    document.getElementById("availability").innerHTML = doctor.availability;

} else {

    window.location.href = "login.html";

}

function logout() {

    localStorage.removeItem("doctor");

    window.location.href = "login.html";

}