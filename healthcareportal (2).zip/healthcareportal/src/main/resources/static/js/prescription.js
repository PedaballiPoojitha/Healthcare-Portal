const params = new URLSearchParams(window.location.search);
const appointmentId = params.get("id");

document
    .getElementById("prescriptionForm")
    .addEventListener("submit", savePrescription);

async function savePrescription(e) {

    e.preventDefault();

    const prescription = {

        appointment: {
            id: Number(appointmentId)
        },

        diagnosis: document.getElementById("diagnosis").value,
        medicines: document.getElementById("medicines").value,
        dosage: document.getElementById("dosage").value,
        notes: document.getElementById("notes").value
    };

    const response = await fetch(
        "http://localhost:8080/api/prescriptions",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(prescription)
        });

    if (response.ok) {

        alert("Prescription Saved Successfully");

        window.location.href = "doctor-appointments.html";

    } else {

        const error = await response.json();

        alert(error.message);

    }
}