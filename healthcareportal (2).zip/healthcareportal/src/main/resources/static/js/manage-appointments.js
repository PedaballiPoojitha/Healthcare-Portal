const API_URL = "http://localhost:8080/api/appointments";

window.onload = function () {
    loadAppointments();
};

async function loadAppointments() {

    try {

        const response = await fetch(API_URL);

        if (!response.ok) {
            throw new Error("Unable to load appointments");
        }

        const appointments = await response.json();

        let rows = "";

        appointments.forEach(app => {

            rows += `
                <tr>

                    <td>${app.id}</td>

                    <td>${app.patient.name}</td>

                    <td>${app.doctor.name}</td>

                    <td>${app.appointmentDate}</td>

                    <td>${app.appointmentTime}</td>

                    <td>${app.reason}</td>

                    <td>
                        <span class="badge bg-primary">
                            ${app.status}
                        </span>
                    </td>

                    <td>

                        <button
                            class="btn btn-danger btn-sm"
                            onclick="deleteAppointment(${app.id})">

                            Delete

                        </button>

                    </td>

                </tr>
            `;

        });

        document.getElementById("appointmentTable").innerHTML = rows;

    }

    catch(error){

        console.log(error);

        alert("Unable to Load Appointments");

    }

}

async function deleteAppointment(id){

    if(!confirm("Delete this appointment?")){
        return;
    }

    try{

        const response = await fetch(
            `${API_URL}/${id}`,
            {
                method:"DELETE"
            }
        );

        if(response.ok){

            alert("Appointment Deleted Successfully");

            loadAppointments();

        }else{

            alert("Unable to Delete Appointment");

        }

    }

    catch(error){

        console.log(error);

        alert("Server Error");

    }

}