const API_URL = "http://localhost:8080/api/doctors";

window.onload = () => {

    loadDoctors();

};

async function loadDoctors() {

    const table = document.getElementById("doctorTable");

    table.innerHTML = `

        <tr>

            <td colspan="10" class="text-center">

                <div class="spinner-border text-success"></div>

                <br><br>

                Loading Doctors...

            </td>

        </tr>

    `;

    try {

        const response = await fetch(API_URL);

        if (!response.ok) {

            throw new Error("Unable to load doctors");

        }

        const doctors = await response.json();

        document.getElementById("totalDoctors").innerHTML = doctors.length;

        let rows = "";

        if (doctors.length === 0) {

            rows = `

                <tr>

                    <td colspan="10" class="text-center text-danger">

                        No Doctors Found

                    </td>

                </tr>

            `;

        }

        else {

            doctors.forEach((doctor, index) => {

                rows += `

                <tr>

                    <td>${index + 1}</td>

                    <td>${doctor.name}</td>

                    <td>${doctor.email}</td>

                    <td>${doctor.phone}</td>

                    <td>

                        <span class="badge bg-success">

                            ${doctor.specialization}

                        </span>

                    </td>

                    <td>${doctor.qualification}</td>

                    <td>${doctor.experience} Years</td>

                    <td>

                        ₹ ${doctor.consultationFee}

                    </td>

                    <td>${doctor.availability}</td>

                    <td>

                        <button

                            class="btn btn-info btn-sm"

                            onclick="viewDoctor(${doctor.id})">

                            <i class="fa fa-eye"></i>

                        </button>

                        <button

                            class="btn btn-danger btn-sm"

                            onclick="deleteDoctor(${doctor.id})">

                            <i class="fa fa-trash"></i>

                        </button>

                    </td>

                </tr>

                `;

            });

        }

        table.innerHTML = rows;

    }

    catch (error) {

        console.error(error);

        table.innerHTML = `

            <tr>

                <td colspan="10"

                    class="text-center text-danger">

                    Unable to Load Doctors

                </td>

            </tr>

        `;

    }

}

async function deleteDoctor(id) {

    if (!confirm("Delete this doctor?")) {

        return;

    }

    try {

        const response = await fetch(`${API_URL}/${id}`, {

            method: "DELETE"

        });

        if (response.ok) {

            alert("Doctor Deleted Successfully");

            loadDoctors();

        }

        else {

            alert("Unable to Delete Doctor");

        }

    }

    catch {

        alert("Server Error");

    }

}

async function viewDoctor(id) {

    try {

        const response = await fetch(`${API_URL}/${id}`);

        const doctor = await response.json();

        alert(

            `Doctor Details

Name : ${doctor.name}

Email : ${doctor.email}

Phone : ${doctor.phone}

Specialization : ${doctor.specialization}

Qualification : ${doctor.qualification}

Experience : ${doctor.experience} Years

Consultation Fee : ₹${doctor.consultationFee}

Availability : ${doctor.availability}`

        );

    }

    catch {

        alert("Unable to Fetch Doctor Details");

    }

}

function searchDoctor() {

    let input = document.getElementById("search").value.toUpperCase();

    let rows = document.getElementById("doctorTable")
        .getElementsByTagName("tr");

    for (let i = 0; i < rows.length; i++) {

        let name = rows[i].getElementsByTagName("td")[1];

        if (name) {

            let value = name.textContent || name.innerText;

            rows[i].style.display =
                value.toUpperCase().indexOf(input) > -1
                    ? ""
                    : "none";

        }

    }

}

function exportDoctors() {

    const rows = document.querySelectorAll("#doctorTable tr");

    let csv = "S.No,Name,Email,Phone,Specialization,Qualification,Experience,Consultation Fee,Availability\n";

    rows.forEach(row => {

        const cols = row.querySelectorAll("td");

        if (cols.length > 0) {

            let rowData = [];

            // Ignore last column (Actions)
            for (let i = 0; i < cols.length - 1; i++) {

                let text = cols[i].innerText
                    .replace(/\n/g, " ")
                    .replace(/,/g, " ");

                rowData.push(`"${text}"`);
            }

            csv += rowData.join(",") + "\n";
        }

    });

    const blob = new Blob([csv], {
        type: "text/csv;charset=utf-8;"
    });

    const link = document.createElement("a");

    link.href = URL.createObjectURL(blob);

    link.download = "Doctors.csv";

    link.click();

}