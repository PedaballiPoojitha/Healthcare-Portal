const API_URL = "http://localhost:8080/api/patients";

document.getElementById("registerForm").addEventListener("submit", async function(e){

    e.preventDefault();

    const patient = {

        name: document.getElementById("name").value,

        email: document.getElementById("email").value,

        password: document.getElementById("password").value,

        phone: document.getElementById("phone").value,

        gender: document.getElementById("gender").value,

        age: parseInt(document.getElementById("age").value),

        address: document.getElementById("address").value

    };

    try{

        const response = await fetch(API_URL,{

            method:"POST",

            headers:{
                "Content-Type":"application/json"
            },

            body:JSON.stringify(patient)

        });

        if(response.ok){

            alert("Registration Successful!");

            window.location.href="login.html";

        }else{

            alert("Registration Failed!");

        }

    }catch(error){

        console.error(error);

        alert("Server Error!");

    }

});