package com.healthcare.portal.repository;

import com.healthcare.portal.entity.Prescription;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PrescriptionRepository extends JpaRepository<Prescription, Long> {

    List<Prescription> findByAppointmentPatientId(Long patientId);

    Optional<Prescription> findByAppointmentId(Long appointmentId);
}