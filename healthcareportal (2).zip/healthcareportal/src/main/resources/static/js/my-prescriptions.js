const patient = JSON.parse(localStorage.getItem("patient"));

if (!patient) {

    window.location.href = "login.html";

}

loadPrescriptions();

async function loadPrescriptions() {

    try {

        const response = await fetch(
            `http://localhost:8080/api/prescriptions/patient/${patient.id}`
        );

        const prescriptions = await response.json();

        let rows = "";

        if (prescriptions.length === 0) {

            rows = `
                <tr>
                    <td colspan="6" class="text-center">
                        No Prescriptions Available
                    </td>
                </tr>
            `;

        } else {

            prescriptions.forEach(p => {

                rows += `

                <tr>

                    <td>${p.id}</td>

                    <td>${p.appointment.doctor.name}</td>

                    <td>${p.diagnosis}</td>

                    <td>${p.medicines}</td>

                    <td>${p.dosage}</td>

                    <td>${p.notes}</td>

                </tr>

                `;

            });

        }

        document.getElementById("prescriptionTable").innerHTML = rows;

    }

    catch(error){

        console.log(error);

        alert("Unable to Load Prescriptions");

    }

}