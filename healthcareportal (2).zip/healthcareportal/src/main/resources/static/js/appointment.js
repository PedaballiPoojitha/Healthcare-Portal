const doctor = JSON.parse(localStorage.getItem("doctor"));

if (!doctor) {
    window.location.href = "login.html";
}

fetch(`http://localhost:8080/api/appointments/doctor/${doctor.id}`)
    .then(response => response.json())
    .then(data => {

        let rows = "";

        data.forEach(app => {

            rows += `
        <tr>

            <td>${app.id}</td>

            <td>${app.patient.name}</td>

            <td>${app.appointmentDate}</td>

            <td>${app.appointmentTime}</td>

            <td>${app.reason}</td>

            <td>${app.status}</td>

            <td>

            <button
            class="btn btn-success btn-sm"
            onclick="writePrescription(${app.id})">

            Prescription

            </button>

            </td>

        </tr>
        `;

        });

        document.getElementById("appointmentTable").innerHTML = rows;

    });

function writePrescription(id){

    localStorage.setItem("appointmentId",id);

    window.location.href="prescription.html";

}