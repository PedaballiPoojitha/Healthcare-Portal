package com.healthcare.portal.dto;

public class LoginRequest {
}
