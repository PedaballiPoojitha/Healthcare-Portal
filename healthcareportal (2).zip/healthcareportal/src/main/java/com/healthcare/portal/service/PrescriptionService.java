package com.healthcare.portal.service;

import com.healthcare.portal.entity.Prescription;

import java.util.List;

public interface PrescriptionService {

    Prescription savePrescription(Prescription prescription);

    List<Prescription> getAllPrescriptions();

    Prescription getPrescriptionById(Long id);

    Prescription updatePrescription(Long id, Prescription prescription);
    List<Prescription> getPrescriptionsByPatient(Long patientId);

    void deletePrescription(Long id);
}