const patient = JSON.parse(localStorage.getItem("patient"));

if (!patient) {
    alert("Please login first");
    window.location.href = "login.html";
}

async function loadAppointments() {

    try {

        const response = await fetch(
            `http://localhost:8080/api/appointments/patient/${patient.id}`
        );

        if (!response.ok) {
            throw new Error("Unable to fetch appointments");
        }

        const appointments = await response.json();
        console.log("Patient ID:", patient.id);

        console.log("Appointments:", appointments);

        const table = document.getElementById("appointmentTable");

        table.innerHTML = "";

        if (appointments.length === 0) {

            table.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center text-danger">
                        No Appointments Found
                    </td>
                </tr>
            `;
            return;
        }

        appointments.forEach(app => {

            table.innerHTML += `
                <tr>
                    <td>${app.id}</td>
                    <td>${app.doctor.name}</td>
                    <td>${app.doctor.specialization}</td>
                    <td>${app.appointmentDate}</td>
                    <td>${app.appointmentTime}</td>
                    <td>${app.reason}</td>
                    <td>${app.status}</td>
                </tr>
            `;

        });

    } catch (error) {

        console.error(error);
        alert("Error loading appointments");

    }

}

loadAppointments();