package com.healthcare.portal.serviceimpl;

import com.healthcare.portal.entity.Patient;
import com.healthcare.portal.exception.ResourceNotFoundException;
import com.healthcare.portal.repository.PatientRepository;
import com.healthcare.portal.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientServiceImpl implements PatientService {

    @Autowired
    private PatientRepository repository;

    @Override
    public Patient savePatient(Patient patient) {
        return repository.save(patient);
    }

    @Override
    public List<Patient> getAllPatients() {
        return repository.findAll();
    }

    @Override
    public Patient getPatientById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient Not Found"));
    }

    @Override
    public Patient updatePatient(Long id, Patient patient) {

        Patient existing = getPatientById(id);

        existing.setName(patient.getName());
        existing.setEmail(patient.getEmail());
        existing.setPassword(patient.getPassword());
        existing.setPhone(patient.getPhone());
        existing.setGender(patient.getGender());
        existing.setAge(patient.getAge());
        existing.setAddress(patient.getAddress());

        return repository.save(existing);
    }

    @Override
    public void deletePatient(Long id) {
        repository.deleteById(id);
    }
    @Override
    public Patient login(String email, String password) {

        return repository.findByEmailAndPassword(email, password)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Invalid Email or Password"));
    }
}