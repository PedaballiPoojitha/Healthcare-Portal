package com.healthcare.portal.service;

import com.healthcare.portal.entity.Doctor;

import java.util.List;

public interface DoctorService {

    Doctor saveDoctor(Doctor doctor);

    List<Doctor> getAllDoctors();

    Doctor getDoctorById(Long id);

    Doctor updateDoctor(Long id, Doctor doctor);

    void deleteDoctor(Long id);

    List<Doctor> getDoctorsBySpecialization(String specialization);
    Doctor login(String email, String password);
}