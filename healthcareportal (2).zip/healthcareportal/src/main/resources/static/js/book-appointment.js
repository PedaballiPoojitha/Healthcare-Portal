const patient = JSON.parse(localStorage.getItem("patient"));

if (!patient) {

    alert("Please login first");

    window.location.href = "login.html";

}

// Load all doctors
async function loadDoctors() {

    try {

        const response = await fetch("http://localhost:8080/api/doctors");

        const doctors = await response.json();

        const doctorDropdown = document.getElementById("doctor");

        doctors.forEach(doctor => {

            doctorDropdown.innerHTML += `
                <option value="${doctor.id}">
                    Dr. ${doctor.name} - ${doctor.specialization}
                </option>
            `;

        });

    } catch (error) {

        console.error(error);

        alert("Unable to load doctors.");

    }

}

loadDoctors();

// Book appointment
document.getElementById("appointmentForm").addEventListener("submit", async function (e) {

    e.preventDefault();

    const appointment = {

        patient: {
            id: patient.id
        },

        doctor: {
            id: document.getElementById("doctor").value
        },

        appointmentDate: document.getElementById("date").value,

        appointmentTime: document.getElementById("time").value,

        reason: document.getElementById("reason").value,

        status: "Booked"

    };

    try {

        const response = await fetch("http://localhost:8080/api/appointments", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify(appointment)

        });

        if (response.ok) {

            alert("Appointment Booked Successfully!");

            window.location.href = "patient-dashboard.html";

        } else {

            alert("Failed to book appointment.");

        }

    } catch (error) {

        console.error(error);

        alert("Server Error");

    }

});