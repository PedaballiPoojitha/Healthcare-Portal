package com.healthcare.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthcareportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
