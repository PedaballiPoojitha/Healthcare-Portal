const API_URL = "http://localhost:8080/api/prescriptions";

window.onload = function () {

    loadPrescriptions();

};

async function loadPrescriptions() {

    try {

        const response = await fetch(API_URL);

        if (!response.ok) {

            throw new Error("Unable to load prescriptions");

        }

        const prescriptions = await response.json();

        let rows = "";

        prescriptions.forEach(p => {

            rows += `

            <tr>

                <td>${p.id}</td>

                <td>${p.appointment.patient.name}</td>

                <td>${p.appointment.doctor.name}</td>

                <td>${p.diagnosis}</td>

                <td>${p.medicines}</td>

                <td>${p.dosage}</td>

                <td>${p.notes}</td>

                <td>

                    <button
                        class="btn btn-danger btn-sm"
                        onclick="deletePrescription(${p.id})">

                        Delete

                    </button>

                </td>

            </tr>

            `;

        });

        document.getElementById("prescriptionTable").innerHTML = rows;

    }

    catch(error){

        console.log(error);

        alert("Unable to Load Prescriptions");

    }

}

async function deletePrescription(id){

    if(!confirm("Delete this prescription?")){

        return;

    }

    try{

        const response = await fetch(

            `${API_URL}/${id}`,

            {

                method:"DELETE"

            }

        );

        if(response.ok){

            alert("Prescription Deleted Successfully");

            loadPrescriptions();

        }

        else{

            alert("Unable to Delete Prescription");

        }

    }

    catch(error){

        console.log(error);

        alert("Server Error");

    }

}